﻿param([switch]$SelfTest)

# ============================================================
# 文件夹保险箱 FolderVault
# 零依赖本地访问锁：把文件夹设为「隐藏+系统」属性，
# 普通浏览看不到；只有输入正确密码才能打开。
# 注意：这是访问控制，不是文件加密，防的是随手点开。
# ============================================================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:ConfigPath = Join-Path $PSScriptRoot 'vault.config'
$script:Salt = $null
$script:PasswordHash = $null
$script:Folders = @()

function Get-PasswordHash {
    param([string]$Password, [string]$Salt)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $data = [System.Text.Encoding]::UTF8.GetBytes($Salt + '|' + $Password)
        return [Convert]::ToBase64String($sha.ComputeHash($data))
    } finally {
        $sha.Dispose()
    }
}

function New-Salt {
    return [guid]::NewGuid().ToString('N')
}

function Load-Config {
    $script:Salt = $null
    $script:PasswordHash = $null
    $script:Folders = @()
    if (-not (Test-Path -LiteralPath $script:ConfigPath)) { return }
    try {
        $json = Get-Content -LiteralPath $script:ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($json.Salt) { $script:Salt = [string]$json.Salt }
        if ($json.PasswordHash) { $script:PasswordHash = [string]$json.PasswordHash }
        if ($json.Folders) { $script:Folders = @($json.Folders | ForEach-Object { [string]$_ }) }
    } catch {
        # 配置损坏时按首次运行处理
    }
}

function Save-Config {
    $obj = [ordered]@{
        Salt         = $script:Salt
        PasswordHash = $script:PasswordHash
        Folders      = @($script:Folders)
    }
    $json = $obj | ConvertTo-Json -Depth 5
    [System.IO.File]::WriteAllText($script:ConfigPath, $json, [System.Text.UTF8Encoding]::new($false))
}

function Set-FolderLockState {
    param([string]$Path, [bool]$Hide)
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    try {
        $item = Get-Item -LiteralPath $Path -Force
        $attr = [int]$item.Attributes
        if ($Hide) {
            $attr = $attr -bor 2 -bor 4
        } else {
            $attr = $attr -band (-bnot 2) -band (-bnot 4)
        }
        $item.Attributes = [System.IO.FileAttributes]$attr
        return $true
    } catch {
        return $false
    }
}

function Show-PasswordInput {
    param([string]$Title, [string]$LabelText)

    $form = New-Object System.Windows.Forms.Form
    $form.Text = $Title
    $form.Width = 390
    $form.Height = 165
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $LabelText
    $lbl.Left = 20; $lbl.Top = 22; $lbl.Width = 340
    $form.Controls.Add($lbl)

    $txt = New-Object System.Windows.Forms.TextBox
    $txt.UseSystemPasswordChar = $true
    $txt.Left = 20; $txt.Top = 52; $txt.Width = 334
    [void]$txt.Focus()
    $form.Controls.Add($txt)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = '确定'
    $btnOK.Left = 188; $btnOK.Top = 90; $btnOK.Width = 78
    $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.Controls.Add($btnOK)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = '取消'
    $btnCancel.Left = 276; $btnCancel.Top = 90; $btnCancel.Width = 78
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.Controls.Add($btnCancel)

    # 不写任何事件脚本块：用按钮内置的 DialogResult 关闭窗体，
    # 密码值在 ShowDialog 返回后直接从文本框读取，彻底避开事件作用域问题。
    $form.AcceptButton = $btnOK
    $form.CancelButton = $btnCancel

    [void]$txt.Focus()
    $result = $form.ShowDialog()
    $answer = [string]$txt.Text
    $form.Dispose()

    if ($result -eq [System.Windows.Forms.DialogResult]::OK) { return $answer }
    return $null
}

function Set-NewPassword {
    while ($true) {
        $p1 = Show-PasswordInput '设置密码' '请设置密码：'
        if ($null -eq $p1) { return $false }
        if ([string]::IsNullOrWhiteSpace($p1)) {
            [void][System.Windows.Forms.MessageBox]::Show('密码不能为空', '提示', 'OK', 'Warning')
            continue
        }
        $p2 = Show-PasswordInput '确认密码' '请再次输入密码：'
        if ($null -eq $p2) { return $false }
        if ($p1 -ceq $p2) {
            $script:Salt = New-Salt
            $script:PasswordHash = Get-PasswordHash $p1 $script:Salt
            Save-Config
            return $true
        }
        [void][System.Windows.Forms.MessageBox]::Show('两次输入不一致，请重试', '错误', 'OK', 'Error')
    }
}

function Test-Password {
    $pwd = Show-PasswordInput '身份验证' '请输入密码：'
    if ($null -eq $pwd) { return $false }
    if ((Get-PasswordHash $pwd $script:Salt) -eq $script:PasswordHash) { return $true }
    [void][System.Windows.Forms.MessageBox]::Show('密码错误', '错误', 'OK', 'Error')
    return $false
}

# ---------- 自检模式：不弹界面，仅验证核心逻辑 ----------
if ($SelfTest) {
    $h1 = Get-PasswordHash 'abc123' 'fixed-salt'
    $h2 = Get-PasswordHash 'abc123' 'fixed-salt'
    $h3 = Get-PasswordHash 'abc124' 'fixed-salt'
    Write-Output "HashStable=$($h1 -eq $h2)"
    Write-Output "HashDifferent=$($h1 -ne $h3)"

    $tmp = Join-Path $env:TEMP ('fvtest_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tmp | Out-Null
    Set-FolderLockState $tmp $true | Out-Null
    $a1 = [int](Get-Item -LiteralPath $tmp -Force).Attributes
    Write-Output "HiddenSet=$((($a1 -band 2) -eq 2) -and (($a1 -band 4) -eq 4))"
    Set-FolderLockState $tmp $false | Out-Null
    $a2 = [int](Get-Item -LiteralPath $tmp -Force).Attributes
    Write-Output "HiddenCleared=$((($a2 -band 2) -eq 0) -and (($a2 -band 4) -eq 0))"
    Remove-Item -LiteralPath $tmp -Force -Recurse

    $oldCfg = $script:ConfigPath
    $script:ConfigPath = Join-Path $env:TEMP ('fvcfg_' + [guid]::NewGuid().ToString('N') + '.json')
    $script:Salt = 'unit-salt'
    $script:PasswordHash = Get-PasswordHash 'pw' 'unit-salt'
    $script:Folders = @('C:\folder-a')
    Save-Config
    $script:Salt = $null; $script:PasswordHash = $null; $script:Folders = @()
    Load-Config
    $ok = ($script:Salt -eq 'unit-salt') -and
          ($script:PasswordHash -eq (Get-PasswordHash 'pw' 'unit-salt')) -and
          ($script:Folders.Count -eq 1) -and
          ($script:Folders[0] -eq 'C:\folder-a')
    Write-Output "ConfigRoundTrip=$ok"
    Remove-Item -LiteralPath $script:ConfigPath -Force
    $script:ConfigPath = $oldCfg

    # 验证按钮 DialogResult 已正确设置（纯 .NET 属性，不依赖事件脚本块）
    $probeForm = New-Object System.Windows.Forms.Form
    $probeOK = New-Object System.Windows.Forms.Button
    $probeOK.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $probeCancel = New-Object System.Windows.Forms.Button
    $probeCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    Write-Output "PwdOkPath=$($probeOK.DialogResult -eq [System.Windows.Forms.DialogResult]::OK)"
    Write-Output "PwdCancelPath=$($probeCancel.DialogResult -eq [System.Windows.Forms.DialogResult]::Cancel)"
    $probeForm.Dispose()

    exit
}

# ---------- 正常启动 ----------
Load-Config
if (-not $script:PasswordHash) {
    if (-not (Set-NewPassword)) { exit }
}

$mainForm = New-Object System.Windows.Forms.Form
$mainForm.Text = '文件夹保险箱'
$mainForm.Width = 580
$mainForm.Height = 430
$mainForm.StartPosition = 'CenterScreen'
$mainForm.FormBorderStyle = 'FixedDialog'
$mainForm.MaximizeBox = $false

$header = New-Object System.Windows.Forms.Label
$header.Text = "受保护的文件夹（已隐藏，只能通过本工具输入密码打开）"
$header.Left = 24; $header.Top = 18; $header.Width = 520; $header.Height = 22
$mainForm.Controls.Add($header)

$listBox = New-Object System.Windows.Forms.ListBox
$listBox.Left = 24; $listBox.Top = 48; $listBox.Width = 510; $listBox.Height = 230
$mainForm.Controls.Add($listBox)

$lblCount = New-Object System.Windows.Forms.Label
$lblCount.Left = 24; $lblCount.Top = 288; $lblCount.Width = 510; $lblCount.Height = 20
$mainForm.Controls.Add($lblCount)

$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = '添加文件夹'
$btnAdd.Left = 24; $btnAdd.Top = 320; $btnAdd.Width = 100; $btnAdd.Height = 34
$mainForm.Controls.Add($btnAdd)

$btnOpen = New-Object System.Windows.Forms.Button
$btnOpen.Text = '打开（需密码）'
$btnOpen.Left = 134; $btnOpen.Top = 320; $btnOpen.Width = 120; $btnOpen.Height = 34
$mainForm.Controls.Add($btnOpen)

$btnRemove = New-Object System.Windows.Forms.Button
$btnRemove.Text = '取消保护'
$btnRemove.Left = 264; $btnRemove.Top = 320; $btnRemove.Width = 100; $btnRemove.Height = 34
$mainForm.Controls.Add($btnRemove)

$btnLockAll = New-Object System.Windows.Forms.Button
$btnLockAll.Text = '全部上锁'
$btnLockAll.Left = 374; $btnLockAll.Top = 320; $btnLockAll.Width = 90; $btnLockAll.Height = 34
$mainForm.Controls.Add($btnLockAll)

$btnPwd = New-Object System.Windows.Forms.Button
$btnPwd.Text = '修改密码'
$btnPwd.Left = 474; $btnPwd.Top = 320; $btnPwd.Width = 60; $btnPwd.Height = 34
$mainForm.Controls.Add($btnPwd)

$footer = New-Object System.Windows.Forms.Label
$footer.Text = "提示：使用后点「全部上锁」重新隐藏；忘记密码无法找回，请自行保管。"
$footer.Left = 24; $footer.Top = 366; $footer.Width = 520; $footer.Height = 20
$mainForm.Controls.Add($footer)

function Refresh-FolderList {
    $listBox.Items.Clear()
    foreach ($f in $script:Folders) { [void]$listBox.Items.Add($f) }
    $lblCount.Text = "已保护 $($script:Folders.Count) 个文件夹"
}

$btnAdd.add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = '选择要保护的文件夹'
    $dlg.ShowNewFolderButton = $false
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $p = $dlg.SelectedPath
        if ($script:Folders -contains $p) {
            [void][System.Windows.Forms.MessageBox]::Show('该文件夹已在保护列表中', '提示', 'OK', 'Information')
            return
        }
        if (Set-FolderLockState $p $true) {
            $script:Folders += $p
            Save-Config
            Refresh-FolderList
            [void][System.Windows.Forms.MessageBox]::Show("已保护：`n$p`n`n该文件夹现已隐藏，只能通过本工具输入密码打开。", '成功', 'OK', 'Information')
        } else {
            [void][System.Windows.Forms.MessageBox]::Show('无法设置文件夹属性，请检查权限', '错误', 'OK', 'Error')
        }
    }
})

$btnOpen.add_Click({
    if ($listBox.SelectedIndex -lt 0) {
        [void][System.Windows.Forms.MessageBox]::Show('请先选择一个文件夹', '提示', 'OK', 'Warning')
        return
    }
    if (-not (Test-Password)) { return }
    $p = [string]$listBox.SelectedItem
    if (Test-Path -LiteralPath $p) {
        Start-Process explorer.exe -ArgumentList "`"$p`""
    } else {
        [void][System.Windows.Forms.MessageBox]::Show('文件夹不存在或已被移动，请在列表中取消保护后重新添加', '错误', 'OK', 'Error')
    }
})

$btnRemove.add_Click({
    if ($listBox.SelectedIndex -lt 0) {
        [void][System.Windows.Forms.MessageBox]::Show('请先选择一个文件夹', '提示', 'OK', 'Warning')
        return
    }
    if (-not (Test-Password)) { return }
    $p = [string]$listBox.SelectedItem
    Set-FolderLockState $p $false | Out-Null
    $script:Folders = @($script:Folders | Where-Object { $_ -ne $p })
    Save-Config
    Refresh-FolderList
})

$btnLockAll.add_Click({
    foreach ($f in $script:Folders) { Set-FolderLockState $f $true | Out-Null }
    [void][System.Windows.Forms.MessageBox]::Show('已全部重新上锁', '提示', 'OK', 'Information')
})

$btnPwd.add_Click({
    if (-not (Test-Password)) { return }
    if (Set-NewPassword) {
        [void][System.Windows.Forms.MessageBox]::Show('密码已修改', '提示', 'OK', 'Information')
    }
})

Refresh-FolderList
[void]$mainForm.ShowDialog()
